package com.example.myapplication.viewModel

import androidx.lifecycle.ViewModel
import com.example.myapplication.model.CotizacionEstado
import com.example.myapplication.model.CotizacionItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class CotizacionViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(CotizacionEstado())
    val uiState: StateFlow<CotizacionEstado> = _uiState.asStateFlow()

    fun cambiarMoneda(nuevaMoneda: String) {
        _uiState.update { it.copy(moneda = nuevaMoneda) }
    }

    fun agregarProducto(descripcion: String, precio: Double, cantidad: Int = 1) {
        val nuevoItem = CotizacionItem(descripcion, precio, cantidad)
        _uiState.update { it.copy(items = it.items + nuevoItem) }
    }

    fun calcularSubtotal(): Double {
        return _uiState.value.items.sumOf { it.precio * it.cantidad }
    }

    fun calcularImpuesto(): Double {
        return calcularSubtotal() * 0.19
    }

    fun calcularTotalFinal(): Double {
        return calcularSubtotal() + calcularImpuesto()
    }

    fun eliminarProducto(descripcion: String) {
        _uiState.update { estadoActual ->
            val nuevaLista = estadoActual.items.filterNot { it.descripcion == descripcion }
            estadoActual.copy(items = nuevaLista)
        }
    }
}
